package com.mobile2app.inventorytracker.ui.main;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.mobile2app.inventorytracker.ui.fragments.NotificationsFragment;
import com.mobile2app.inventorytracker.R;
import com.mobile2app.inventorytracker.data.InventoryDatabase;
import com.mobile2app.inventorytracker.ui.fragments.InventoryFragment;
import com.mobile2app.inventorytracker.ui.login.LoginActivity;

// The Main Activity - Contains an upper "Navigation" Bar with a Logout and Notifications button
// Most app activity are built inside the FrameView @id/fragment_container
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EdgeToEdge.enable(this);
        // Load InventoryFragment
        if (savedInstanceState == null) {
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.fragment_container, new InventoryFragment());
            fragmentTransaction.commit();
        }
    }

    // Opens a NotificationsFragment
    // Called by notification button on_click
    public void openNotifications(View view) {
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragment_container, new NotificationsFragment());
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();

    }

    // Creates a system dialog box asking if the user would like to logout
    // finishes this activity and opens a logout activity after removing logged in user from system
    // called by log out button (logo image)
    public void openLogoutDialog(View view) {
        // build an alert dialog with Logout or Cancel options, call Logout method when logging out
        // and go to logout activity
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Logout");
        builder.setMessage("Are you sure you want to log out? \nUnsaved changes may be lost");

        // "Logout" button
        builder.setPositiveButton("Logout", ((dialog, which) -> {
            InventoryDatabase database = new InventoryDatabase(this);
            // remove user from stored userID and return to logout screen if logout successful
            Log.d("MAINACTIVITY", "logout success?");

            if (database.logout()) {
                // Start Logout activity and finish MainActivity
                startActivity(new Intent(MainActivity.this, LoginActivity.class));
                finish();
                Toast.makeText(this, "Logout Successful", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Logout Failed", Toast.LENGTH_SHORT).show();

            }
        }));

        // "Cancel" button to dismiss dialog
        builder.setNegativeButton("Cancel", ((dialog, which) -> dialog.dismiss()));
        builder.setCancelable(true);

        // Display Dialog
        builder.create().show();


    }
}


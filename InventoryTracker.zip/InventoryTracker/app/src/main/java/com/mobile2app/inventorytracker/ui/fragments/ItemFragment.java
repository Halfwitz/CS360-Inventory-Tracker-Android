package com.mobile2app.inventorytracker.ui.fragments;

import android.graphics.Color;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.mobile2app.inventorytracker.R;
import com.mobile2app.inventorytracker.data.InventoryDatabase;
import com.mobile2app.inventorytracker.data.Item;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ItemFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ItemFragment extends Fragment {

    private boolean newItem;

    private Item item; // current item being edited
    private InventoryDatabase database;

    // Edit text fields to populate or retrieve data from
    private EditText editName, editDescription, editUpc, editQuantity;
    // Buttons used to save changes or delete the item
    private Button buttonSaveChanges, buttonDeleteItem;

    // the fragment initialization parameters
    private static final String ARG_ITEM_ID = "item_id";

    public ItemFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param id item id used by the InventoryDatabase db
     * @return A new instance of fragment ItemFragment.
     */
    public static ItemFragment newInstance(int id) {
        ItemFragment fragment = new ItemFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_ITEM_ID, id);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        database = new InventoryDatabase(getContext());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_item, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        // get UI components
        ImageButton buttonBack = view.findViewById(R.id.button_back);
        editName = view.findViewById(R.id.edit_name);
        editDescription = view.findViewById(R.id.edit_description);
        editUpc = view.findViewById(R.id.edit_UPC);
        editQuantity = view.findViewById(R.id.edit_quantity);

        // instantiates item with existing data if an item id was provided
        if (getArguments() != null) {
            int itemId = getArguments().getInt(ARG_ITEM_ID);
            item = database.getItem(itemId);
        }

        // if item was instantiated (presumably with values) prefill UI components
        if (item != null) {
            newItem = false;
            editName.setText(item.getName());
            editDescription.setText(item.getDescription());
            editUpc.setText(item.getUpc());
            editQuantity.setText(String.valueOf(item.getQuantity()));
        } else { // instantiate item with blank values
            newItem = true;
            item = new Item("", "", "", 1);
        }

        // set listeners for save/delete buttons
        buttonSaveChanges = view.findViewById(R.id.button_save_changes);
        buttonDeleteItem = view.findViewById(R.id.button_delete_item);
        buttonSaveChanges.setOnClickListener(this::saveChanges);
        buttonDeleteItem.setOnClickListener(this::deleteItem);

        // if item is new, change text and buttons
        if (newItem) {
            TextView title = view.findViewById(R.id.text_screen_title);
            title.setText(R.string.title_screen_new_item);
            buttonDeleteItem.setText(R.string.cancel);
            buttonSaveChanges.setText(R.string.button_save_new_item);
        }

        // set listeners to enable or disable save button if any field is changed
        TextWatcher watcher = new TextWatcher() { // call toggleSave when text is changed
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                toggleSave();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        };

        // add watcher listener to each field
        editName.addTextChangedListener(watcher);
        editDescription.addTextChangedListener(watcher);
        editUpc.addTextChangedListener(watcher);
        editQuantity.addTextChangedListener(watcher);

        // set callback for back button to return to previous screen if there are unsaved changes
        buttonBack.setOnClickListener(this::clickBack);
    }

    // enables or disables save changes if any fields are changed
    private void toggleSave() {
        // if all edit fields are the same as the original values, disable save button
        if (hasChanges()) { // green button, enabled
            buttonSaveChanges.setBackgroundColor(Color.parseColor("#33AA33"));
            buttonSaveChanges.setEnabled(true);
        } else { //gray button, disabled
            buttonSaveChanges.setBackgroundColor(Color.parseColor("#9e998d"));
            buttonSaveChanges.setEnabled(false);
        }
    }

    // true if any fields have changed
    private boolean hasChanges() {
        return !(editName.getText().toString().equals(item.getName()) &&
                editDescription.getText().toString().equals(item.getDescription()) &&
                editQuantity.getText().toString().equals(String.valueOf(item.getQuantity())) &&
                editUpc.getText().toString().equals(item.getUpc()));

    }
    private void saveChanges(View view) {
        // get each edittext value
        item.setName(editName.getText().toString().trim());
        item.setDescription(editDescription.getText().toString().trim());
        item.setUpc(editUpc.getText().toString().trim());
        // try/catch for quantity to catch NumberFormatException
        try {
            item.setQuantity(Integer.parseInt(editQuantity.getText().toString().trim()));
        } catch (NumberFormatException e) {
            Toast.makeText(requireContext(), "Invalid quantity!", Toast.LENGTH_SHORT).show();
            return;
        }

        // warn if name or quantity fields are empty
        if (item.getName().isBlank()) {
            Toast.makeText(requireContext(), "Name field is required", Toast.LENGTH_SHORT).show();
            return;
        }

        // if item id = -1, add to database as a new item
        if (item.getId() == -1) {
            if (database.addItem(item) > 0) {
                Toast.makeText(requireContext(), "Item Added!", Toast.LENGTH_SHORT).show();
                requireActivity().getSupportFragmentManager().popBackStack();
            }
            else {
                Toast.makeText(requireContext(), "Failed to save new item.", Toast.LENGTH_SHORT).show();
                return;
            }
        }
        // if item id != -1, attempt to update an existing item in the database
        else {
            if (database.updateItem(item)) {
                Toast.makeText(requireContext(), "Item Updated!", Toast.LENGTH_SHORT).show();
                requireActivity().getSupportFragmentManager().popBackStack();


            }
        }
    }

    // if item id != -1, attempt to delete an existing item in the database
    private void deleteItem(View view) {
        if (item.getId() != -1) {
            if (database.deleteItem(item.getId())) {
                Toast.makeText(requireContext(), "Item Deleted", Toast.LENGTH_SHORT).show();

                requireActivity().getSupportFragmentManager().popBackStack();
            } else {
                Toast.makeText(requireContext(),
                        "Failed to delete item.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // returns to previous screen, confirms if user wants to save unchanged changes using Alert
    private void clickBack(View view) {
        // build an alert dialog with Logout or Cancel options, call Logout method when logging out
        // and go to logout activity
        if (hasChanges()) {
            AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
            builder.setTitle("Go Back");
            builder.setMessage("Are you sure you want to back? \nUnsaved changes will be lost");

            // "Continue" button
            builder.setPositiveButton("Continue",
                    ((dialog, which) -> requireActivity().getSupportFragmentManager().popBackStack()));

            // Cancel button
            builder.setNegativeButton("Cancel", (((dialog, which) -> dialog.dismiss())));

            // show dialog
            builder.create().show();
        }
        else {
            requireActivity().getSupportFragmentManager().popBackStack();
        }

    }
}
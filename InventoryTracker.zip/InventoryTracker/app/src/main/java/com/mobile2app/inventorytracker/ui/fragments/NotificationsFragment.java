package com.mobile2app.inventorytracker.ui.fragments;

import android.Manifest;
import static android.Manifest.permission.SEND_SMS;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.google.android.material.materialswitch.MaterialSwitch;
import com.mobile2app.inventorytracker.R;
import com.mobile2app.inventorytracker.data.InventoryDatabase;

// follows android workflow for requesting permissions
//(https://developer.android.com/training/permissions/requesting#workflow_for_requesting_permissions)

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link NotificationsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class NotificationsFragment extends Fragment {

    InventoryDatabase database;
    ActivityResultLauncher smsPermissionLauncher;

    TextView status;
    TextView permissionMessage;


    public NotificationsFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment
     *
     * @return A new instance of fragment NotificationsFragment.
     */

    public static NotificationsFragment newInstance() {
        NotificationsFragment fragment = new NotificationsFragment();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // define how permission request is handled
        smsPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(), isGranted -> {
                    if (isGranted) {
                        // permission is granted
                        status.setVisibility(View.INVISIBLE);
                        permissionMessage.setVisibility(View.INVISIBLE);

                    } else {
                        // permission not granted -- features unavailable.
                        // turn off switch, show message
                        status.setVisibility(View.VISIBLE);
                        MaterialSwitch switchSMS = getView().findViewById(R.id.switch_alerts);
                        if (switchSMS != null) {
                            switchSMS.setChecked(false);
                        }
                    }
                });
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_notifications, container, false);
    }

    public void onViewCreated(View view, Bundle savedInstanceState) {
        // get UI components
        EditText editPhoneNumber = view.findViewById(R.id.edit_phone_number);
        MaterialSwitch switchSMS = view.findViewById(R.id.switch_alerts);
        Button buttonRequestPerm = view.findViewById(R.id.button_request_permission);
        ImageButton buttonBack = view.findViewById(R.id.button_back);
        status = view.findViewById(R.id.text_permission_status);
        permissionMessage = view.findViewById(R.id.text_alert_explanation);

        // show status message and grant permission if SMS permission not granted
        boolean initialPermission = hasSmsPermission();
        buttonRequestPerm.setVisibility(initialPermission ? View.INVISIBLE : View.VISIBLE);
        status.setVisibility(initialPermission ? View.INVISIBLE : View.VISIBLE);
        permissionMessage.setVisibility(initialPermission ? View.INVISIBLE : View.VISIBLE);

        // retrieve user ID and phone number from database and SharedPreferences
        SharedPreferences prefs = requireContext().getSharedPreferences("user_prefs", Context.MODE_PRIVATE);
        database = new InventoryDatabase(requireContext());
        int userID = prefs.getInt("user_id", -1); // defaults to -1 if not found
        String phoneNumber = database.getPhoneNumber(userID);
        // returns true if alerts are enabled for a specific userID.
        boolean alertsEnabled =
                prefs.getBoolean("alerts_enabled_for_" + userID, false);
        switchSMS.setChecked(alertsEnabled);
        // prefill phone number if already provided
        if (phoneNumber != null) {
            editPhoneNumber.setText(phoneNumber);
        }

        // set callback for back button to return to previous screen
        buttonBack.setOnClickListener(
                v -> requireActivity().getSupportFragmentManager().popBackStack());

        // save phone number to database when edited
        editPhoneNumber.setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus) {
                // save phone number to database for current logged in userID (numbers only)
                String newPhoneNumber = editPhoneNumber.getText()
                        .toString().replaceAll("[^0-9]", ""); // digits only
                if (newPhoneNumber.isEmpty()) {
                    return; // TODO: add no phone number warning
                } else {
                    // save phone number to database
                    database.updatePhoneNumber(userID, newPhoneNumber);
                }
            }
        });

        // set listener to save phone number and grant SMS permission when clicking button
        buttonRequestPerm.setOnClickListener(v -> {

            // requests SMS permission if not granted, or shows UI message explaining permission
            requestPermission(view);
        });

        // set listener if switch is toggle. if permissions not granted, request permission.
        // if request denied, toggle switch back
        switchSMS.setOnCheckedChangeListener(((buttonView, isChecked) -> {
            if (isChecked && userID != -1) {
                if (!hasSmsPermission()) {
                    requestPermission(view);
                    // if user denies, switch off
                    if (!hasSmsPermission()) {
                        switchSMS.setChecked(false); // *triggers listener again*
                        return;
                    }
                }
                // set alerts_enabled in shared prefs to true
                prefs.edit().putBoolean("alerts_enabled_for_"+userID, true).apply();

            } else { // switch is off
                // set alerts boolean to false
                prefs.edit().putBoolean("alerts_enabled_for_"+userID, false).apply();
            }
        }));
    }

    // check if user has SMS permission, return true if they do
    public boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(
                requireContext(), Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    // Request SMS permission
    private void requestPermission(View view) {
        // check if user has sms permission, if not enable UI describing why or request perms
        if (hasSmsPermission()) { // hide permission message
            permissionMessage.setVisibility(View.INVISIBLE);
        } else if (shouldShowRequestPermissionRationale(SEND_SMS)) {
            // show Permission message
            permissionMessage.setVisibility(View.VISIBLE);
        } else { // request permission
            smsPermissionLauncher.launch(SEND_SMS);
        }
    }
}
package com.mobile2app.inventorytracker.data;


import android.content.Context;
import android.graphics.Color;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.mobile2app.inventorytracker.ui.fragments.ItemFragment;
import com.mobile2app.inventorytracker.ui.main.MainActivity;
import com.mobile2app.inventorytracker.R;

// represents a single row in the item grid created using appropriate View components
// applies listeners to buttons for appropriate handling
public class ItemRow {
    private final Context context;
    private final Item item;
    private final InventoryDatabase database;

    // UI components
    private final ImageButton buttonDelete;
    private final TextView textItemName;
    private final ImageButton buttonEdit;
    private final LinearLayout quantityControls;
    private ImageButton buttonDecreaseQty;
    private EditText editQty;
    private ImageButton buttonIncreaseQty;

    // constructor for row
    public ItemRow(Context context, Item item, InventoryDatabase database) {
        this.context = context;
        this.item = item;
        this.database = database;

        // initialize each component after receiving item
        buttonDelete = createDeleteButton();
        textItemName = createItemNameText();
        buttonEdit = createEditButton();
        quantityControls = createQtyControls();
    }

    // return each created button in a view containing all row elements in the expected order
    public View[] getViews() {
        return new View[]{buttonDelete, textItemName, buttonEdit, quantityControls};
    }

    // adds the decrease, increase quantity buttons and edit field to a linear layout component
    // adds listeners to each
    private LinearLayout createQtyControls() {
        // create each component of the linear layout (creates listeners
        LinearLayout controls = new LinearLayout(context);
        buttonDecreaseQty = createDecreaseQtyButton();
        buttonIncreaseQty = createIncreaseQtyButton();
        editQty = createQtyEditText();

        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER);

        LinearLayout.LayoutParams linearParam = new LinearLayout.LayoutParams(
                0,LinearLayout.LayoutParams.WRAP_CONTENT);
        GridLayout.LayoutParams params = new GridLayout.LayoutParams(linearParam);
        params.columnSpec = GridLayout.spec(3, 1, 3f);


        controls.setLayoutParams(params);

        // add components to linear layout and return
        controls.addView(buttonDecreaseQty);
        controls.addView(editQty);
        controls.addView(buttonIncreaseQty);
        return controls;
    }

    private ImageButton createDeleteButton() {
        ImageButton button = new ImageButton(context);
        // set the attributes to style the component
        button.setId(item.getId());
        button.setImageResource(R.drawable.vec_delete);
        button.setBackground(null);
        button.setContentDescription("Remove Item From Table");
        button.setColorFilter(context.getColor(R.color.primaryBackground));

        // set additional attributes using a LayoutParams object for the Grid layout component
        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width = dpToPx(48);
        params.height = dpToPx(48);
        params.setMargins(0,0,0,0);
        params.columnSpec = GridLayout.spec(0, 1);
        button.setLayoutParams(params);

        // delete this item from database when clicked, and delete all views from the row
        button.setOnClickListener(v -> {
            if (database.deleteItem(item.getId())) { // if the item is deleted, remove views
                GridLayout grid = (GridLayout) button.getParent();
                int itemIndex = grid.indexOfChild(button); // row index of this row
                // delete each column + the divider in the row
                for (int i = 4; i >= 0; i--) {
                    // removes view at current index + 4...0, (each column)
                    grid.removeView(grid.getChildAt(itemIndex + i));
                }
                Toast.makeText(context, "Item Deleted", Toast.LENGTH_SHORT).show();
            }
        });

        return button;
    }

    private TextView createItemNameText() {
        TextView text = new TextView(context);
        text.setText(item.getName());
        text.setGravity(Gravity.CENTER);

        // set additional attributes using a LayoutParams object for the Grid layout component
        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width = 0;
        params.height = GridLayout.LayoutParams.WRAP_CONTENT;
        params.columnSpec = GridLayout.spec(1, 1, 4f);
        params.setGravity(Gravity.FILL);
        params.setMargins(0,0,0,0);

        text.setLayoutParams(params);

        return text;
    }

    private ImageButton createEditButton() {
        ImageButton button = new ImageButton(context);
        button.setImageResource(R.drawable.vec_edit);
        button.setColorFilter(Color.parseColor("#555555"));
        button.setBackground(null);
        button.setContentDescription("Edit Item");

        // set additional attributes using a LayoutParams object for the Grid layout component
        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width = dpToPx(48);
        params.height = dpToPx(48);
        params.setGravity(Gravity.CENTER_VERTICAL);
        params.setMargins(0,0,dpToPx(0),0);
        params.columnSpec = GridLayout.spec(2, 1);

        button.setLayoutParams(params);

        // open edit fragment with item details when clicked
        button.setOnClickListener(v -> {
            // creates new fragment with item id as the argument
            ItemFragment fragment = ItemFragment.newInstance(item.getId());
            FragmentManager fragmentManager = ((MainActivity) context).getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.fragment_container, fragment);
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.commit();
        });

        return button;
    }

    private ImageButton createDecreaseQtyButton() {
        ImageButton button = new ImageButton(context);
        button.setImageResource(R.drawable.vec_minus);
        button.setBackground(null);
        button.setContentDescription("Decrease Quantity by 1");
        button.setColorFilter(context.getColor(R.color.primaryBackground));

        // set additional attributes using a LayoutParams object for the Grid layout component
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dpToPx(48),dpToPx(48));
        button.setLayoutParams(params);

        // decrease item quantity in database and onscreen by 1 on click
        button.setOnClickListener(v -> {
            // get current quantity and decrement it by 1
            int quantity = item.getQuantity();
            quantity--;
            // update the quantity of the item in the database and the EditText with new quantity
            if (database.updateItemQuantity(item.getId(), quantity)) { // true means item updated
                item.setQuantity(quantity);
                editQty.setText(String.valueOf(quantity));
            }
        });

        return button;
    }

    private ImageButton createIncreaseQtyButton() {
        ImageButton button = new ImageButton(context);
        button.setImageResource(R.drawable.vec_plus);
        button.setBackground(null);
        button.setContentDescription("Increase Quantity by 1");
        button.setColorFilter(context.getColor(R.color.primaryBackground));


        // set additional attributes using a LayoutParams object for the Grid layout component
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dpToPx(48),dpToPx(48));
        button.setLayoutParams(params);

        // increase item quantity in database and onscreen by 1 on click
        button.setOnClickListener(v -> {
            // get current quantity and increment it by 1
            int quantity = item.getQuantity();
            quantity++;
            // update the quantity of the item in the database and the EditText with new quantity
            if (database.updateItemQuantity(item.getId(), quantity)) { // true means item updated
                item.setQuantity(quantity);
                editQty.setText(String.valueOf(quantity));
            }
        });

        return button;
    }

    private EditText createQtyEditText() {
        EditText edit = new EditText(context);
        // input a number (positive or negative)
        edit.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        edit.setGravity(Gravity.CENTER);
        edit.setText(String.valueOf(item.getQuantity()));

        // when focusing off of this element, use its value to set the quantity in db
        edit.setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus) { // user has clicked off of this item after focusing it
                String qty = edit.getText().toString().trim();
                try { // in case converting to integer fails
                    int newQty = Integer.parseInt(qty);
                    // update database if quantity changed
                    if (newQty != item.getQuantity()) {
                        item.setQuantity(newQty);
                        database.updateItemQuantity(item.getId(), newQty);
                    }
                    // quantity was not valid format
                } catch (NumberFormatException e) {
                    edit.setText(String.valueOf(item.getQuantity()));
                    Toast.makeText(context, "Invalid Quantity", Toast.LENGTH_SHORT).show();
                }
            }
        });

        return edit;
    }

    // converts the desired dp amount (density-independent pixels) to the pixel amount based on
    // the devices screen density
    // (referenced https://developer.android.com/guide/practices/screens_support.html#screen-independence)
    private int dpToPx(int dp) {
        float density = context.getResources().getDisplayMetrics().density;
        return (int) (dp * density + 0.5f); // number of pixels
    }
}

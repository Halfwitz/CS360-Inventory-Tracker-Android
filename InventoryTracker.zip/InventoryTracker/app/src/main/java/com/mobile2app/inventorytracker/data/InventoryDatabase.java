package com.mobile2app.inventorytracker.data;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.telephony.SmsManager;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

public class InventoryDatabase extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "inventory.db";
    private static final int VERSION = 4;

    private final Context context;

    public InventoryDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
        this.context = context;
    }

    // Table used to track user logins
    private static final class LoginTable {
        private static final String TABLE = "logins";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
        private static final String COL_PHONE = "phone_number";
    }

    // Table used to track items in the database
    private static final class InventoryTable {
        private static final String TABLE = "items";
        private static final String COL_ID = "_id";
        private static final String COL_NAME = "name";
        private static final String COL_DESCRIPTION = "description";
        private static final String COL_QUANTITY = "quantity";
        private static final String COL_UPC = "upc";
    }
    // called when database is first create, contains code to create all the tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        // create the table for storing logins
        db.execSQL(
            "create table " + LoginTable.TABLE + " (" +
            LoginTable.COL_ID + " integer primary key autoincrement, " +
            LoginTable.COL_USERNAME + " text unique, " + // "unique" prevents multiple logins w/ same username
            LoginTable.COL_PASSWORD + " text, " +
            LoginTable.COL_PHONE + " text)"
        );
        // create the table for storing items
        db.execSQL(
            "create table " + InventoryTable.TABLE + " (" +
            InventoryTable.COL_ID + " integer primary key autoincrement, " +
            InventoryTable.COL_NAME + " text, " +
            InventoryTable.COL_DESCRIPTION + " text, " +
            InventoryTable.COL_QUANTITY + " integer, " +
            InventoryTable.COL_UPC + " text)"
        );
    }

    // called when tables are modified (drop/create/transfer old to new)
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + LoginTable.TABLE);
        db.execSQL("drop table if exists " + InventoryTable.TABLE);
        onCreate(db);
    }

    /******INVENTORY TABLE METHODS*****/
    // get all items - retrieves a list containing all entries in Inventory table
    // item list returned in alphabetical order by name, or empty list if not items are in
    // the database
    public List<Item> getAllItems() {
        List<Item> items = new ArrayList<>(); // will populate with each item
        SQLiteDatabase db = getReadableDatabase(); // read access to entries

        Cursor query = db.query(
                InventoryTable.TABLE, // from this table
                new String[]{InventoryTable.COL_ID, InventoryTable.COL_NAME,  // get each column
                             InventoryTable.COL_DESCRIPTION, InventoryTable.COL_QUANTITY,
                             InventoryTable.COL_UPC},
                null,
                null,
                null,
                null,
                InventoryTable.COL_NAME + " ASC" // order by name alphabetical ascending
        );
        // if there are entries, move through them until last row has been processed
        while (query.moveToNext()) {
            int id = query.getInt(query.getColumnIndexOrThrow(InventoryTable.COL_ID));
            String name = query.getString(query.getColumnIndexOrThrow(InventoryTable.COL_NAME));
            String description = query.getString(query.getColumnIndexOrThrow(InventoryTable.COL_DESCRIPTION));
            int quantity = query.getInt(query.getColumnIndexOrThrow(InventoryTable.COL_QUANTITY));
            String upc = query.getString(query.getColumnIndexOrThrow(InventoryTable.COL_UPC));

            items.add(new Item(id, name, description, upc, quantity));
        }

        query.close();
        return items;

    }

    // get item with given id, if it exists. Else returns null
    public Item getItem(int id) {
        SQLiteDatabase db = getReadableDatabase();
        // create Cursor to iterate database columns where col_id = id
        Cursor query = db.query(
                InventoryTable.TABLE, // from this table
                new String[]{
                        // get each column
                        InventoryTable.COL_ID,
                        InventoryTable.COL_NAME,
                        InventoryTable.COL_DESCRIPTION,
                        InventoryTable.COL_QUANTITY,
                        InventoryTable.COL_UPC
                },
                InventoryTable.COL_ID + " = ?", // WHERE col_id matches ?
                new String[]{String.valueOf(id)},
                null,
                null,
                null
        );

        // create the item at first Cursor position and return if it exists, else return null.
        if (query.moveToFirst()) {
            int itemId = query.getInt(query.getColumnIndexOrThrow(InventoryTable.COL_ID));
            String name = query.getString(query.getColumnIndexOrThrow(InventoryTable.COL_NAME));
            String description = query.getString(query.getColumnIndexOrThrow(InventoryTable.COL_DESCRIPTION));
            int quantity = query.getInt(query.getColumnIndexOrThrow(InventoryTable.COL_QUANTITY));
            String upc = query.getString(query.getColumnIndexOrThrow(InventoryTable.COL_UPC));

            query.close();
            return new Item(id, name, description, upc, quantity);
        }
        // item with id does not exist
        query.close();
        return null;

    }

    // add an item entry to the InventoryTable, returns row id of new entry or -1 if insertion fails
    public long addItem(String name, String description, int quantity, String upc) {
        // database to write to
        SQLiteDatabase db = getWritableDatabase();

        // hold values to be inserted to InventoryTable
        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_NAME, name);
        values.put(InventoryTable.COL_DESCRIPTION, description);
        values.put(InventoryTable.COL_QUANTITY, quantity);
        values.put(InventoryTable.COL_UPC, upc);

        return db.insert(InventoryTable.TABLE, null, values);
    }

    // add an item to the table with an item object. ID is discarded and item is given the next
    // id in the database
    public long addItem(Item item) {
        // extract data
        String name = item.getName();
        String description = item.getDescription();
        int quantity = item.getQuantity();
        String upc = item.getUpc();
        // insert data into database
        return addItem(name, description, quantity, upc);
    }

    // updates the item specified id with the updated name, description, quantity, and upc
    // returns true if update successful
    public boolean updateItem(int id, String name, String description, int quantity, String upc) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_NAME, name);
        values.put(InventoryTable.COL_DESCRIPTION, description);
        values.put(InventoryTable.COL_QUANTITY, quantity);
        values.put(InventoryTable.COL_UPC, upc);

        // gets rows affected by updating entries to new values if the id equals given argument 'id'
        int updated = db.update(InventoryTable.TABLE, values, "_id = ?",
                new String[] { String.valueOf(id) });
        boolean success = updated > 0;
        if (success) {
            if (quantity <= 0) {
                Log.d("Database", "sending no stock alert" );

                sendNoStockAlert(getItem(id).getName());
            }
        }
        return success; // true if an item was modified
    }

    // modifies item matching the given item object ID with the fields Item, returns true if update
    // successful
    public boolean updateItem(Item item) {
        // extract data
        int id = item.getId();
        String name = item.getName();
        String description = item.getDescription();
        int quantity = item.getQuantity();
        String upc = item.getUpc();
        // update existing item in database
        return updateItem(id, name, description, quantity, upc);
    }

    // update the items quantity only
    public boolean updateItemQuantity(int id, int quantity) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(InventoryTable.COL_QUANTITY, quantity);

        // gets rows affected by updating entries to new values if the id equals given argument 'id'
        int updated = db.update(InventoryTable.TABLE, values, "_id = ?",
                new String[] { String.valueOf(id) });
        boolean success = updated > 0;
        if (success) {
            if (quantity <= 0) {
                sendNoStockAlert(getItem(id).getName());
            }
        }
        return success; // true if an item was modified
    }

    // delete item row from table
    public boolean deleteItem(long id) {
        SQLiteDatabase db = getWritableDatabase(); // used to write to db

        // gets rows affected by deleting entries where the id equals given argument 'id'
        int deleted = db.delete(InventoryTable.TABLE, InventoryTable.COL_ID + " = ?",
                new String[] { String.valueOf(id) });
        return deleted > 0; // true if a row was deleted
    }

    // send a SMS message to logged in user with the message if the user has permission
    private void sendNoStockAlert(String itemName) {
        SharedPreferences prefs =
                context.getSharedPreferences("user_prefs", Context.MODE_PRIVATE);
        int userId = prefs.getInt("user_id", -1);
        boolean alertsEnabled = prefs.getBoolean("alerts_enabled_for_"+userId, false);
        String phoneNumber = getPhoneNumber(userId);

        // userId exists, user has alerts enabled, and phone number is not null.
        if (userId != -1 && alertsEnabled && phoneNumber != null ) {
            SmsManager smsManager = SmsManager.getDefault();
            String message = "Inventory Tracker Stock Alert:\n" + itemName + " has reached a quantity of 0 or below.";
            try {
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            } catch (Exception e) {
                Log.d("Database", "Could not send text: " + e.getMessage());
            }

        }
    }

    /******LOGIN TABLE METHODS*******/
    // returns true if the database login table contains the given username argument already
    private boolean hasUsername(String username) {
        SQLiteDatabase db = getReadableDatabase();

        // query the table to see if logins exist with the given username
        Cursor query = db.query(
                LoginTable.TABLE, // table name to query against
                new String[]{LoginTable.COL_USERNAME}, // list of columns (query the username col)
                LoginTable.COL_USERNAME + " = ?", // WHERE clause 'username' = ?
                new String[]{username}, // replace ? with username in WHERE clause (selection arg)
                null,
                null,
                null);

        // true if table already contains username
        boolean hasUsername = query.getCount() > 0;
        query.close();
        return hasUsername;
    }

    // used to add a new login to the database
    // returns new row's ID or -1 if error occurred
    public long addLogin(String username, String password) {
        // if username is already in db, cannot create a new login with the username
        if (hasUsername(username)) return -1;

        // obtains a writeable SQLiteDatabase
        SQLiteDatabase db = getWritableDatabase();

        // holds table columns and data to be inserted
        ContentValues values = new ContentValues();

        values.put(LoginTable.COL_USERNAME, username);
        values.put(LoginTable.COL_PASSWORD, password);

        // insert username/password into db and return id of new row
        return db.insert(LoginTable.TABLE, null, values);
    }

    public boolean updatePhoneNumber(int userId, String phoneNumber) {
        SQLiteDatabase db = getWritableDatabase(); // used to add/modify phone number

        ContentValues values = new ContentValues();
        values.put(LoginTable.COL_PHONE, phoneNumber);

        int updated =  db.update(
                LoginTable.TABLE,
                values,
                LoginTable.COL_ID + " = ?",
                new String[]{String.valueOf(userId)});

        return updated > 0; // true if a value was updated
    }
    // returns user phone number stored in COL_PHONE column of Login table, or null if not exist
    public String getPhoneNumber(int userId) {
        SQLiteDatabase db = getReadableDatabase();
        // return Cursor pointing to phone number for given user id
        Cursor query =  db.query(
                LoginTable.TABLE,
                new String[]{LoginTable.COL_PHONE},
                LoginTable.COL_ID + " = ?",
                new String[]{String.valueOf(userId)},
                null,null,null);

        // if first value in query is phone number, return it
        if (query.moveToFirst()) {
            String phoneNumber = query.getString(query.getColumnIndexOrThrow(LoginTable.COL_PHONE));
            query.close();
            return phoneNumber;
        }

        // phone number doesn't exist for given user id, return null
        query.close();
        return null;
    }

    // authenticate given username and password against the database and return userID or -1
    public int login(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();

        // query the table to see if logins exist with the given username
        Cursor query = db.query(
                LoginTable.TABLE, // table name to query against
                new String[]{LoginTable.COL_ID}, // list of columns (ids)
                LoginTable.COL_USERNAME + " = ? AND " + LoginTable.COL_PASSWORD + " = ?", // WHERE
                new String[]{username, password}, // replace ? ? with credentials (selection args)
                null,
                null,
                null);
        // get user id and return it if its in the query
        if (query.moveToFirst()) {
            int userID = query.getInt(query.getColumnIndexOrThrow(LoginTable.COL_ID));
            query.close();
            return userID;
        } else { // User is unable to authenticate, return -1
            query.close();
            return -1;
        }
    }

    // removes userID from "user_id" SharedPreferences value. return true if successful.
    public boolean logout() {
        SharedPreferences prefs = context.getSharedPreferences("user_prefs", Context.MODE_PRIVATE);
        if (prefs.contains("user_id")) {
            // prevents skipping login when logging out.
            prefs.edit().remove("user_id").apply();
            return !prefs.contains("user_id");
        }
        return false;
    }
}

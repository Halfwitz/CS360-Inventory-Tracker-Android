package com.mobile2app.inventorytracker.ui.fragments;

import android.graphics.Color;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridLayout;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.mobile2app.inventorytracker.data.Item;
import com.mobile2app.inventorytracker.data.ItemRow;
import com.mobile2app.inventorytracker.R;
import com.mobile2app.inventorytracker.data.InventoryDatabase;

import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link InventoryFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
// represents the primary screen for viewing the inventory, adding/deleting items, and updating
// item quantities.
public class InventoryFragment extends Fragment {
    private InventoryDatabase database;
    private GridLayout gridLayout;

    private FloatingActionButton fab;

    public InventoryFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment
     *
     * @return A new instance of fragment InventoryFragment.
     */
    public static InventoryFragment newInstance() {
        InventoryFragment fragment = new InventoryFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        database = new InventoryDatabase(getContext());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_inventory, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        gridLayout = view.findViewById(R.id.grid_layout_inventory);
        populateInventory();

        fab = view.findViewById(R.id.add_item_fab);
        fab.setOnClickListener(this::newItem);
    }

    // refresh the inventory screen each time this fragment is resumed
    @Override
    public void onResume() {
        super.onResume();
        populateInventory();
    }


    // retrieves items from the database and populates the grid with dynamic rows
    private void populateInventory() {
        // retrieve all items
        List<Item> items = database.getAllItems();

        // clear grid before adding new rows
        clearGrid();

        // dynamically create views for each column of each item
        // row structure: [delete | name | edit button | linear layout(minus, editText, plus)]
        for (Item item : items) {
            ItemRow itemRow = new ItemRow(requireContext(), item, database); // creates row for item

            // create the row
            for (View view : itemRow.getViews()) { // contains each component of 1 row
                gridLayout.addView(view);
            }
            // create the divider below each row and add to grid
            View divider = new View(getContext());
            divider.setBackgroundColor(Color.parseColor("#999999"));
            GridLayout.LayoutParams params = new GridLayout.LayoutParams();
            params.width = GridLayout.LayoutParams.MATCH_PARENT;
            params.height = 3;
            params.columnSpec = GridLayout.spec(0, 4); // spans 4 columns from column 0
            divider.setLayoutParams(params);
            gridLayout.addView(divider);
        }
    }

    // clears each entry in the grid except for header columns and first divider
    private void clearGrid() {
        int elements = gridLayout.getChildCount(); // total elements in grid
        while (elements > 3) { // should only keep "item" header, "count" header, and divider (3)
            gridLayout.removeViewAt(elements - 1); // removes element at last index
            elements--;
        }
    }

    // open the ItemFragment fragment with blank values
    public void newItem(View view) {
        FragmentManager fragmentManager = requireActivity().getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragment_container, new ItemFragment());
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }
}
package com.mobile2app.inventorytracker.ui.login;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.mobile2app.inventorytracker.ui.main.MainActivity;
import com.mobile2app.inventorytracker.R;
import com.mobile2app.inventorytracker.data.InventoryDatabase;


// Activity that starts when the app first starts
public class LoginActivity extends AppCompatActivity {

    // UI Components
    private InventoryDatabase database;
    private EditText usernameEditText;
    private EditText passwordEditText;
    private TextView warningText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        // get UI components
        database = new InventoryDatabase(getApplicationContext());
        usernameEditText = findViewById(R.id.edit_username);
        passwordEditText = findViewById(R.id.edit_password);
        warningText = findViewById(R.id.text_login_failed);
        Button loginButton = findViewById(R.id.button_login);
        Button signUpButton = findViewById(R.id.button_signup);

        // Skip Login if User_ID is already contained in shared preferences
        SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
        if (prefs.contains("user_id")) {
            // launch main activity
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(intent);
            finish(); // prevents users from navigating back to login with "back" button
        }

        // add listeners to disable login/signup buttons if no text is entered to either field
        usernameEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // if EditText contains 0 chars make Buttons invisible, otherwise Buttons visible.
                int visibility = usernameEditText.length() == 0 || passwordEditText.length() == 0 ?
                        View.INVISIBLE : View.VISIBLE;
                loginButton.setVisibility(visibility);
                signUpButton.setVisibility(visibility);
                // enable or disable button as well
                loginButton.setEnabled(usernameEditText.length() != 0);
            }
            @Override
            public void afterTextChanged(Editable s) { }
        });
        passwordEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // if EditText contains 0 chars make Buttons invisible, otherwise Buttons visible.
                int visibility = usernameEditText.length() == 0 || passwordEditText.length() == 0 ?
                        View.INVISIBLE : View.VISIBLE;
                loginButton.setVisibility(visibility);
                loginButton.setEnabled(visibility == View.VISIBLE); // enable button if visible
                signUpButton.setVisibility(visibility);
                signUpButton.setEnabled(visibility == View.VISIBLE); // enable button if visible
            }
            @Override
            public void afterTextChanged(Editable s) { }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.layout_login), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    // attempt to authenticate the login. if authenticated, move to the main activity, else warn usr
    public void login(View view) {
        // get credentials
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        // launch main activity and store userID in SharedPreferences, if valid
        int userID = database.login(username, password);
        if (userID != -1) {
            warningText.setVisibility(View.INVISIBLE);
            // store UserID
            SharedPreferences prefs = getSharedPreferences("user_prefs", MODE_PRIVATE);
            prefs.edit().putInt("user_id", userID).apply(); // update user_id with new userID.

            // launch main activity
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(intent);
            finish(); // prevents users from navigating back to login with "back" button
        } else {
            // make warning indicating failed login/signup visible
            warningText.setVisibility(View.VISIBLE);
        }
    }

    // create a new account if username doesn't exist in database and logs in with it
    public void signUp(View view) {
        String username = usernameEditText.getText().toString();
        String password = passwordEditText.getText().toString();
        if (database.addLogin(username, password) == -1) { // failed to add login
            warningText.setVisibility(View.VISIBLE);
        } else { // created a new login to login with
            login(view);
        }

    }
}
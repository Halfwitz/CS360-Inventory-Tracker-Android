package com.mobile2app.inventorytracker.data;

// represents a single item
// used to handle Items transitioning from database to on screen for ease of retrieval or
// modification
public class Item {
    private int id;
    private String name, description, upc;
    private int quantity;

    public Item(int id, String name, String description, String upc, int quantity) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.upc = upc;
        this.quantity = quantity;
    }

    // Create item without an ID. ID defaults to invalid id -1 which should be handled by methods
    public Item(String name, String description, String upc, int quantity) {
        this(-1, name, description, upc, quantity);
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getUpc() {
        return upc;
    }

    public void setUpc(String upc) {
        this.upc = upc;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
